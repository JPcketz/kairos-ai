Kairos A.I. Handoff Bundle
Incident: INC-COMPOSITE-1758910306

Contents:
- incident_*.json  (raw machine-readable incident)
- report.html      (pretty HTML report)
- <INC>.pdf        (client-friendly PDF)
- <INC>_playbook.md (step-by-step containment)
- <INC>_ticket.txt (paste into ticketing)
